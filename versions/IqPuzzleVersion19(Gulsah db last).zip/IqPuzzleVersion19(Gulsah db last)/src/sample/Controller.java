package sample;

public class Controller {
    public User user; // this user is set to be user which plays the game -hopefully- and will be passed to Game object.
}
