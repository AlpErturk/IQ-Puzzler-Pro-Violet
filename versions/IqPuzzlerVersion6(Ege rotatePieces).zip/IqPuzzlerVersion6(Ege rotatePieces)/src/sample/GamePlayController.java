package sample;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.Bloom;
import javafx.scene.effect.Glow;
import javafx.scene.effect.Lighting;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import jfxtras.labs.util.event.MouseControlUtil;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.input.*;

import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;

public class GamePlayController implements Initializable {

    final int xTopLeft = 0;
    final int yTopLeft = -560;
    Piece selectedPiece;

    @Override
    public void initialize(URL location, ResourceBundle resources){

        Game game = Game.getInstance();
        Board board = new Board(game.levelOne.getLevelMatrix());

        Stage primaryStage = new Stage();
        //Pane panel = new Pane();
        //Button button = new Button("tria");

        //panel.getChildren().addAll(button);

        //Scene scenel = new Scene(panel);
        //primaryStage.setScene(scenel);
        //primaryStage.show(); //BUNU COMMENTLEDIM BI HATA COZULDU HABERINIZ OLSUN

        BorderPane backgroundPane = new BorderPane();
        Pane boardPane = new Pane();
        HBox menuPane = new HBox();
        menuPane.setMinSize(150,150);
        menuPane.setMaxSize(150, 150);
        Button pauseButton = new Button("Pause");
        Button ege = new Button("Ege");
        Label menuLabel = new Label("MENU");

        pauseButton.setAlignment(Pos.BOTTOM_CENTER);

        menuPane.getChildren().addAll(menuLabel);
        menuPane.getChildren().addAll(ege);
        menuPane.getChildren().addAll(pauseButton);

        String styleMenu = "-fx-background-color: rgba(80,58,37,0);";
        menuPane.setStyle(styleMenu);

        // use it's predefined content pane as pieceBox pane
        Pane pieceBox = new Pane();
        pieceBox.setMaxSize(600, 600);

        ImageView pieceView = game.pieceTen.getCurrentImage();
        ImageView piece2View = game.pieceEleven.getCurrentImage();
        ImageView piece3View = game.pieceTwelve.getCurrentImage();

        MouseControlUtil.makeDraggable(pieceView);
        pieceBox.getChildren().add(pieceView);

        MouseControlUtil.makeDraggable(piece2View);
        pieceBox.getChildren().add(piece2View);

        MouseControlUtil.makeDraggable(piece3View);
        pieceBox.getChildren().add(piece3View);

        pieceView.setLayoutX(40);
        pieceView.setLayoutY(10);

        piece2View.setLayoutX(280);
        piece2View.setLayoutY(10);

        piece3View.setLayoutX(570);
        piece3View.setLayoutY(10);

//----------------------------------------------------------------------------------------------------------------------

        //BOARD MATRIXI INITIALIZE EDILIYOR VE BIR MATRIX XPOSITIONLARI TUTUYOR BIR MATRIX YPOSITIONLARI TUTUYOR
        //BIR MATRIX TUM BOARD ENTRYLERININ BOS OLUP OLMADIGINI TUTUYOR

        //Boardun constructorinda initialize edilece

        double [][]XboardMatrix = new double[5][11];
        double [][]YboardMatrix = new double[5][11];

        int [][] isFull = game.levelOne.getLevelMatrix();


        for(int i = 0; i < 5; i++) {
            for(int j =0; j < 11; j++) {
                XboardMatrix[i][j] = 70 * j;
                YboardMatrix[i][j] = -560 + (70 * i);
            }
        }

//--------------------------------------------------------------------------------------------------

        //MOUSE RELEASED EVENT HANDLER
        //This code calculates the position of piece
        EventHandler handler = new EventHandler() {
            @Override
            public void handle(Event event){

                if(event.getSource() == game.pieceTen.getCurrentImage() ) {
                    System.out.println("Layout X10: " +game.pieceTen.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceTen.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceView, 40, 10)) {
                        board.putPiece(game.pieceTen, XboardMatrix, YboardMatrix, 40, 10);
                    }
                }

                else if(event.getSource() == game.pieceEleven.getCurrentImage()) {
                    System.out.println("Layout X11: " +game.pieceEleven.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y11: " +game.pieceEleven.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(piece2View, 280, 10)) {
                        board.putPiece(game.pieceEleven, XboardMatrix, YboardMatrix, 300, 10);
                    }
                }

                else if(event.getSource() == game.pieceTwelve.getCurrentImage()) {
                    System.out.println("Layout X12: " +game.pieceTwelve.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y12: " +game.pieceTwelve.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(piece3View, 570, 10)) {
                        board.putPiece(game.pieceTwelve, XboardMatrix, YboardMatrix, 600, 100);
                    }
                }

            }
        };

//--------------------------------------------------------------------------------------------------


        //MOUSE Pressed EVENT HANDLER
        //This code calculates the position of piece
        EventHandler pressedHandler = new EventHandler() {
            @Override
            public void handle(Event event) {
                if (event.getSource() == game.pieceTen.getCurrentImage()) {
                    selectedPiece = game.pieceTen;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceTen.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                } else if (event.getSource() == game.pieceEleven.getCurrentImage()) {
                    selectedPiece = game.pieceEleven;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceEleven.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                } else if (event.getSource() == game.pieceTwelve.getCurrentImage()) {
                    selectedPiece = game.pieceTwelve;
                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceTwelve.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }
            }
        };

//--------------------------------------------------------------------------------------------------



        //MOUSE Pressed EVENT HANDLER
        //This code calculates the position of piece
        EventHandler rightPressedHandler = new EventHandler() {
            @Override
            public void handle(Event event) {

                if (event.getSource() == game.pieceTen.getCurrentImage()) {
                    game.pieceTen.getCurrentImage().setRotate(game.pieceTen.getCurrentImage().getRotate() + 90);
                    Bloom bloom = new Bloom();
                    game.pieceTen.getCurrentImage().setCache(true);
                    bloom.setThreshold(1.0);
                    game.pieceTen.getCurrentImage().setSmooth(true);


                } else if (event.getSource() == game.pieceEleven.getCurrentImage()) {
                    game.pieceEleven.getCurrentImage().setRotate(game.pieceEleven.getCurrentImage().getRotate() + 90);



                } else if (event.getSource() == game.pieceTwelve.getCurrentImage()) {
                    game.pieceTwelve.getCurrentImage().setRotate(game.pieceTwelve.getCurrentImage().getRotate() + 90);

                }
            }
        };


        backgroundPane.addEventFilter(KeyEvent.KEY_PRESSED, event->{
            if (event.getCode() == KeyCode.SPACE) {
                selectedPiece.getCurrentImage().setRotate(selectedPiece.getCurrentImage().getRotate()+90);
                //System.out.println("")
            }
        });



//--------------------------------------------------------------------------------------------------

        //ADDING EVENTHANDLER TO PIECES
        game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);
        //game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_CLICKED, handler);

        game.pieceEleven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceEleven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED,  pressedHandler);

        game.pieceTwelve.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceTwelve.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED,  pressedHandler);


//--------------------------------------------------------------------------------------------------

        pieceBox.setMaxSize(300, 300);
        pieceBox.setMinSize(300,300);

        String style = "-fx-background-color: rgba(241, 235, 174, 0.8);";
        backgroundPane.setStyle(style);
        boardPane.getChildren().addAll(board.getBoardView());
        backgroundPane.setCenter(boardPane);
        backgroundPane.setBottom(pieceBox);
        backgroundPane.setTop(menuPane);

//--------------------------------------------------------------------------------------------------

        // add the scalable pane to the scene
        Scene scene = new Scene(backgroundPane, 775, 1000);


        // setup the stage
        primaryStage.setTitle("IQ PUZZLER PRO");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setResizable(false);

    }

}
