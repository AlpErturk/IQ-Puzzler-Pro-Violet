package sample;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.ImageCursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.Bloom;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import jfxtras.labs.util.event.MouseControlUtil;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import java.awt.MouseInfo;

import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;

public class GamePlayController implements Initializable {

    final int xTopLeft = 0;
    final int yTopLeft = -560;
    final int sceneWidth = 1500;
    final int sceneHeight = 1000;
    public static int timerPosition = 0;
    Piece selectedPiece;
    int currentLevel = 0;
    int hammerClickCount = 0;
    int iceBreakClickCount = 0;
    boolean hammerButtonClicked = false;


    @Override
    public void initialize(URL location, ResourceBundle resources){


        Game game = Game.getInstance();
        //Level[] levels = new Level[10];

        Board board = new Board(game.levelTwo.getLevelMatrix(), sceneWidth, sceneHeight);

        board.printBoardMatrix();

        Stage primaryStage = new Stage();
        //Pane panel = new Pane();
        //Button button = new Button("tria");

        //panel.getChildren().addAll(button);

        //Scene scenel = new Scene(panel);
        //primaryStage.setScene(scenel);
        //primaryStage.show(); //BUNU COMMENTLEDIM BI HATA COZULDU HABERINIZ OLSUN



        BorderPane backgroundPane = new BorderPane();
        HBox menuPane = new HBox();
        menuPane.setMinSize(150,150);
        menuPane.setMaxSize(150, 150);
        Button pauseButton = new Button("Pause");
        Button ege = new Button("Ege");



        Label menuLabel = new Label("MENU");
        pauseButton.setAlignment(Pos.BOTTOM_CENTER);

        menuPane.getChildren().addAll(menuLabel);
        menuPane.getChildren().addAll(ege);
        menuPane.getChildren().addAll(pauseButton);

        //------------------------------------------------------------------------------------------------------------------------------
        // add the scalable pane to the scene
        Scene scene = new Scene(backgroundPane, sceneWidth, sceneHeight);

        // setup the stageprimaryStage.setTitle("IQ PUZZLER PRO");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setResizable(false);
        //------------------------------------------------------------------------------------------------------------------------------

        //---------------------------------------------------------------------------------------------
        Button hammerButton = new Button("hammer");
        hammerButton.setGraphic(new ImageView("file:/Users/alper/Desktop/111/images/hammer.png"));
        menuPane.getChildren().addAll(hammerButton);
        hammerButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                Image hammerImage = new Image("file:/Users/alper/Desktop/111/images/hammer.png");
                ImageCursor cursor = new ImageCursor(hammerImage, 0, 0);
                scene.setCursor(cursor);
                hammerButtonClicked = true;
            }
        });
        //---------------------------------------------------------------------------------------------


        String styleMenu = "-fx-background-color: rgba(80,58,37,0);";
        menuPane.setStyle(styleMenu);

        // use it's predefined content pane as pieceBox pane
        Pane pieceBox = new Pane();
        pieceBox.setMinHeight(sceneHeight - menuPane.getHeight());
        pieceBox.setMinWidth(sceneWidth);

        ImageView boardView = board.getBoardView();

        //Level 2 Pieces
        ImageView pieceTwoView = game.pieceTwo.getCurrentImage();
        ImageView pieceFiveView = game.pieceFive.getCurrentImage();
        ImageView pieceSixView = game.pieceSix.getCurrentImage();

        //Level 1 Pieces
        ImageView pieceView = game.pieceTen.getCurrentImage();
        ImageView piece2View = game.pieceEleven.getCurrentImage();
        ImageView piece3View = game.pieceTwelve.getCurrentImage();
        Image timerImage = new Image("file:/Users/alper/Desktop/111/images/bounce.png");




        //------------------------------------------------------------------------------------------------------------------------------
        //BOARD MATRIXI INITIALIZE EDILIYOR VE BIR MATRIX XPOSITIONLARI TUTUYOR BIR MATRIX YPOSITIONLARI TUTUYOR
        //BIR MATRIX TUM BOARD ENTRYLERININ BOS OLUP OLMADIGINI TUTUYOR

        //Boardun constructorinda initialize edilece

        double [][]XboardMatrix = new double[5][11];
        double [][]YboardMatrix = new double[5][11];

        int [][] isFull = game.levelOne.getLevelMatrix();


        for(int i = 0; i < 5; i++) {
            for(int j =0; j < 11; j++) {
                XboardMatrix[i][j] = ((sceneWidth-board.getBoardWidth()) / 2)  + (70 * j);
                YboardMatrix[i][j] = 70 * i;
            }
        }
        //------------------------------------------------------------------------------------------------------------------------------

        //Timer Events
        ArrayList<ImageView> iceBlocks = new ArrayList<>();
        ImageView timerView = new ImageView(timerImage);
        pieceBox.getChildren().addAll(timerView);
        timerView.setLayoutY(40);
        timerView.setLayoutX(timerPosition);
        Timer timer = new Timer();
        Timer iceTimer = new Timer();

        TimerTask task = new TimerTask()
        {
            public void run()
            {
                timerView.setLayoutX(timerPosition+=10);
                if(timerPosition > sceneWidth)
                    timerPosition  = 0;
            }

        };

        TimerTask iceTask = new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() ->{
                    ArrayList<Integer> emptyRowPositions = new ArrayList<>();
                    ArrayList<Integer> emptColumnPositions = new ArrayList<>();
                    for(int i = 0; i < 5; i++){ //find empy positions
                        for(int j = 0; j < 11; j++){
                            if(board.boardMatrix[i][j] == 0){
                                emptyRowPositions.add(i);
                                emptColumnPositions.add(j);
                            }
                        }
                    }
                    //choose random empty positions
                    int randomRow1, randomRow2, randomRow3, randomColumn1, randomColumn2, randomColumn3;
                    if(emptyRowPositions.size() >= 3){
                        do{
                            randomRow1 = (int)(Math.random() * emptyRowPositions.size());
                            randomRow2 = (int)(Math.random() * emptyRowPositions.size());
                            randomRow3 = (int)(Math.random() * emptyRowPositions.size());
                            if(randomRow1 != randomRow2 && randomRow1 != randomRow3 && randomRow2 != randomRow3){
                                randomColumn1 = randomRow1;
                                randomColumn2 = randomRow2;
                                randomColumn3 = randomRow3;

                                Image ice = new Image("file:/Users/alper/Desktop/111/images/ice.png");
                                Image ice2 = new Image("file:/Users/alper/Desktop/111/images/ice2.png");
                                Image ice3 = new Image("file:/Users/alper/Desktop/111/images/ice3.png");

                                ImageView ice1View = new ImageView(ice);
                                ImageView ice2View = new ImageView(ice2);
                                ImageView ice3View = new ImageView(ice3);

                                ice1View.setFitHeight(70);
                                ice1View.setFitWidth(70);
                                ice2View.setFitHeight(70);
                                ice2View.setFitWidth(70);
                                ice3View.setFitHeight(70);
                                ice3View.setFitWidth(70);

                                pieceBox.getChildren().add(ice1View);
                                pieceBox.getChildren().add(ice2View);
                                pieceBox.getChildren().add(ice3View);

                                ice1View.relocate(XboardMatrix[emptyRowPositions.get(randomRow1)][emptColumnPositions.get(randomColumn1)], YboardMatrix[emptyRowPositions.get(randomRow1)][emptColumnPositions.get(randomColumn1)]);
                                ice2View.relocate(XboardMatrix[emptyRowPositions.get(randomRow2)][emptColumnPositions.get(randomColumn2)], YboardMatrix[emptyRowPositions.get(randomRow2)][emptColumnPositions.get(randomColumn2)]);
                                ice3View.relocate(XboardMatrix[emptyRowPositions.get(randomRow3)][emptColumnPositions.get(randomColumn3)], YboardMatrix[emptyRowPositions.get(randomRow3)][emptColumnPositions.get(randomColumn3)]);

                                iceBlocks.add(ice1View);
                                iceBlocks.add(ice2View);
                                iceBlocks.add(ice3View);

                                board.boardMatrix[emptyRowPositions.get(randomRow1)][emptColumnPositions.get(randomColumn1)] = -1;
                                board.boardMatrix[emptyRowPositions.get(randomRow2)][emptColumnPositions.get(randomColumn2)] = -1;
                                board.boardMatrix[emptyRowPositions.get(randomRow3)][emptColumnPositions.get(randomColumn3)] = -1;

                                System.out.println("first indexes" + randomRow1 +"," + randomColumn1 );
                                System.out.println("second indexes" + randomRow2 +"," + randomColumn2 );
                                System.out.println("third indexes" + randomRow3 +"," + randomColumn3 );
                                System.out.println("size is: " + iceBlocks.size());
                                break;
                            }
                        }while(randomRow1 != randomRow2 && randomRow1 != randomRow3 && randomRow2 != randomRow3);
                    }
                });
            }
        };

        timer.scheduleAtFixedRate(task,100,100);
        iceTimer.scheduleAtFixedRate(iceTask, 7000, 10000);

        //------------------------------------------------------------------------------------------------------------------------------
        //BUZLARI KIRMA
        scene.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                hammerClickCount++;
                if(hammerButtonClicked){
                    if(hammerClickCount % 2 == 0){
                        Image hammerImage = new Image("file:/Users/alper/Desktop/111/images/hammer20.png");
                        ImageCursor cursor = new ImageCursor(hammerImage, 0, 0);
                        scene.setCursor(cursor);
                    }

                    else{
                        Image hammerImage = new Image("file:/Users/alper/Desktop/111/images/hammer.png");
                        ImageCursor cursor = new ImageCursor(hammerImage, 0, 0);
                        scene.setCursor(cursor);
                    }
                }

                double xClicked = mouseEvent.getX();
                double yClicked = mouseEvent.getY() - 150;

                double boardHeight = 350;
                double boardWidth = 770;
                double sceneWidth = scene.getWidth();
                double sceneHeight = scene.getHeight();
                double leftXCoordinate = (sceneWidth - boardWidth) / 2 ;
                double topYCoordinate = 0;
                double rightXCoordinate = leftXCoordinate + boardWidth;;
                double bottomYCoordinate = boardHeight + topYCoordinate;

                if(((xClicked > leftXCoordinate || xClicked < rightXCoordinate) || (yClicked > topYCoordinate ||yClicked < bottomYCoordinate)) && hammerButtonClicked){
                    int indexColumn = (int)((xClicked - leftXCoordinate) / 70);
                    int indexRow = (int)((yClicked - topYCoordinate) / 70);

                    if(board.boardMatrix[indexRow][indexColumn] == -1){
                        iceBreakClickCount++;
                        for(int i = 0; i < iceBlocks.size(); i++){
                            if(iceBlocks.get(i).getLayoutX() == (XboardMatrix[indexRow][indexColumn]) && iceBlocks.get(i).getLayoutY() == YboardMatrix[indexRow][indexColumn] && iceBreakClickCount == 4){
                                iceBlocks.get(i).setImage(null);
                                board.boardMatrix[indexRow][indexColumn] = 0;
                                iceBlocks.remove(i);
                                iceBreakClickCount = 0;
                            }
                        }
                    }
                }
                else{
                    iceBreakClickCount = 0;
                }
            }
        });

        //------------------------------------------------------------------------------------------------------------------------------
        double []xPositions = new double[9];
        double []yPositions = new double[9];
        //init x positions
        xPositions[0] = 5;
        xPositions[1] = 290;
        xPositions[2] = 575;
        xPositions[3] = 860;
        xPositions[4] = 1145;
        xPositions[5] = 5;
        xPositions[6] = 5;
        xPositions[7] = 775;
        xPositions[8] = 775;

        yPositions[0] = 570;
        yPositions[1] = 570;
        yPositions[2] = 570;
        yPositions[3] = 570;
        yPositions[4] = 570;
        yPositions[5] = 0;
        yPositions[6] = 285;
        yPositions[7] = 0;
        yPositions[8] = 285;

        ArrayList<Piece> unUsuedPieces = game.levelTwo.getUnusedPieces();
        System.out.println(game.levelTwo.getUnusedPieces().get(0).getPieceId());
        ArrayList<ImageView> unUsedPiecesView = new ArrayList<ImageView>();

        //assign imageviews of pieces
        for(int i = 0; i < unUsuedPieces.size(); i++){
            unUsedPiecesView.add(i, unUsuedPieces.get(i).getCurrentImage());
            unUsedPiecesView.get(i).relocate(xPositions[i], yPositions[i]);
            pieceBox.getChildren().add(unUsedPiecesView.get(i));
            MouseControlUtil.makeDraggable(unUsuedPieces.get(i).getCurrentImage());
        }

        pieceBox.getChildren().add(boardView);
        boardView.setLayoutX((sceneWidth-board.getBoardWidth()) / 2 );
        boardView.setLayoutY(0);
//----------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

        //MOUSE RELEASED EVENT HANDLER
        //This code calculates the position of piece
        EventHandler handler = new EventHandler() {
            @Override
            public void handle(Event event){

                if(event.getSource() == game.pieceOne.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceOne.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceOne.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceView, 40, 440)) {
                        board.putPiece(game.pieceOne, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }

                if(event.getSource() == game.pieceTwo.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceTwo.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceTwo.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceTwoView, 40, 440)) {
                        board.putPiece(game.pieceTwo, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }

                if(event.getSource() == game.pieceFive.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceFive.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceFive.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceFiveView, 280, 440)) {
                        board.putPiece(game.pieceFive, XboardMatrix, YboardMatrix, 280, 440);
                    }
                }

                if(event.getSource() == game.pieceSix.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceSix.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceSix.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceSixView, 570, 440)) {
                        board.putPiece(game.pieceSix, XboardMatrix, YboardMatrix, 570, 440);
                    }
                }

                if(event.getSource() == game.pieceTen.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceTen.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceTen.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceView, 40, 440)) {
                        board.putPiece(game.pieceTen, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }

                else if(event.getSource() == game.pieceEleven.getCurrentImage()) {
                    System.out.println("Layout X11: " +game.pieceEleven.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y11: " +game.pieceEleven.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(piece2View, 280, 440)) {
                        board.putPiece(game.pieceEleven, XboardMatrix, YboardMatrix, 280, 440);
                    }
                }

                else if(event.getSource() == game.pieceTwelve.getCurrentImage()) {
                    System.out.println("Layout X12: " +game.pieceTwelve.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y12: " +game.pieceTwelve.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(piece3View, 570, 440)) {
                        board.putPiece(game.pieceTwelve, XboardMatrix, YboardMatrix, 570, 440);
                    }
                }

            }
        };
//--------------------------------------------------------------------------------------------------


        //MOUSE Pressed EVENT HANDLER
        //This code calculates the position of piece
        EventHandler pressedHandler = new EventHandler() {
            @Override
            public void handle(Event event) {
                if (event.getSource() == game.pieceTen.getCurrentImage()) {
                    selectedPiece = game.pieceTen;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceTen.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                } else if (event.getSource() == game.pieceTwo.getCurrentImage()) {
                    selectedPiece = game.pieceTwo;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceTwo.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == game.pieceFive.getCurrentImage()) {
                    selectedPiece = game.pieceFive;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceFive.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == game.pieceSix.getCurrentImage()) {
                    selectedPiece = game.pieceSix;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceSix.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == game.pieceEleven.getCurrentImage()) {
                    selectedPiece = game.pieceEleven;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceEleven.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                } else if (event.getSource() == game.pieceTwelve.getCurrentImage()) {
                    selectedPiece = game.pieceTwelve;
                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceTwelve.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }
            }
        };

//--------------------------------------------------------------------------------------------------
        backgroundPane.addEventFilter(KeyEvent.KEY_PRESSED, event->{
            if (event.getCode() == KeyCode.SPACE) {
                selectedPiece.getCurrentImage().setRotate(selectedPiece.getCurrentImage().getRotate()+90);
                //System.out.println("")
            }
        });


//--------------------------------------------------------------------------------------------------

        //ADDING EVENTHANDLER TO PIECES
        game.pieceTwo.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceTwo.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        game.pieceFive.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceFive.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        game.pieceSix.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceSix.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        //game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_CLICKED, handler);

        game.pieceEleven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceEleven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED,  pressedHandler);

        game.pieceTwelve.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceTwelve.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED,  pressedHandler);

//--------------------------------------------------------------------------------------------------

        String style = "-fx-background-color: rgba(241, 235, 174, 0.8);";
        backgroundPane.setStyle(style);

        backgroundPane.setBottom(pieceBox);
        backgroundPane.setTop(menuPane);

//--------------------------------------------------------------------------------------------------

    }

}
