package sample;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.Bloom;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import jfxtras.labs.util.event.MouseControlUtil;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;

public class GamePlayController implements Initializable {

    final int xTopLeft = 0;
    final int yTopLeft = -560;
    final int sceneWidth = 1500;
    final int sceneHeight = 1000;
    public static int timerPosition = 0;
    Piece selectedPiece;
    int currentLevel = 0;


    @Override
    public void initialize(URL location, ResourceBundle resources){


        Game game = Game.getInstance();
        //Level[] levels = new Level[10];

        Board board = new Board(game.levelTwo.getLevelMatrix(), sceneWidth, sceneHeight);

        board.printBoardMatrix();

        Stage primaryStage = new Stage();
        //Pane panel = new Pane();
        //Button button = new Button("tria");

        //panel.getChildren().addAll(button);

        //Scene scenel = new Scene(panel);
        //primaryStage.setScene(scenel);
        //primaryStage.show(); //BUNU COMMENTLEDIM BI HATA COZULDU HABERINIZ OLSUN

        BorderPane backgroundPane = new BorderPane();
        HBox menuPane = new HBox();
        menuPane.setMinSize(150,150);
        menuPane.setMaxSize(150, 150);
        Button pauseButton = new Button("Pause");
        Button ege = new Button("Ege");
        Label menuLabel = new Label("MENU");

        pauseButton.setAlignment(Pos.BOTTOM_CENTER);

        menuPane.getChildren().addAll(menuLabel);
        menuPane.getChildren().addAll(ege);
        menuPane.getChildren().addAll(pauseButton);

        String styleMenu = "-fx-background-color: rgba(80,58,37,0);";
        menuPane.setStyle(styleMenu);

        // use it's predefined content pane as pieceBox pane
        Pane pieceBox = new Pane();
        pieceBox.setMinHeight(sceneHeight - menuPane.getHeight());
        pieceBox.setMinWidth(sceneWidth);

        ImageView boardView = board.getBoardView();

        //Level 2 Pieces
        ImageView pieceTwoView = game.pieceTwo.getCurrentImage();
        ImageView pieceFiveView = game.pieceFive.getCurrentImage();
        ImageView pieceSixView = game.pieceSix.getCurrentImage();

        //Level 1 Pieces
        ImageView pieceView = game.pieceTen.getCurrentImage();
        ImageView piece2View = game.pieceEleven.getCurrentImage();
        ImageView piece3View = game.pieceTwelve.getCurrentImage();
        Image timerImage = new Image("file:/Users/egeakin/IdeaProjects/Version2IQNude/images/bounce.png");


        ImageView timerView = new ImageView(timerImage);
        pieceBox.getChildren().addAll(timerView);
        timerView.setLayoutY(40);
        timerView.setLayoutX(timerPosition);
        Timer timer = new Timer();

        TimerTask task = new TimerTask()
        {
            public void run()
            {
                timerView.setLayoutX(timerPosition+=10);
                if(timerPosition > sceneWidth)
                    timerPosition  = 0;
            }

        };

        timer.scheduleAtFixedRate(task,100,100);


        MouseControlUtil.makeDraggable(pieceTwoView);
        pieceBox.getChildren().add(pieceTwoView);
        pieceTwoView.setLayoutX(40);
        pieceTwoView.setLayoutY(440);


        MouseControlUtil.makeDraggable(pieceFiveView);
        pieceBox.getChildren().add(pieceFiveView);
        pieceFiveView.setLayoutX(280);
        pieceFiveView.setLayoutY(440);


        MouseControlUtil.makeDraggable(pieceSixView);
        pieceBox.getChildren().add(pieceSixView);
        pieceSixView.setLayoutX(570);
        pieceSixView.setLayoutY(440);

        pieceBox.getChildren().add(boardView);
        boardView.setLayoutX((sceneWidth-board.getBoardWidth()) / 2 );
        boardView.setLayoutY(0);

//----------------------------------------------------------------------------------------------------------------------

        //BOARD MATRIXI INITIALIZE EDILIYOR VE BIR MATRIX XPOSITIONLARI TUTUYOR BIR MATRIX YPOSITIONLARI TUTUYOR
        //BIR MATRIX TUM BOARD ENTRYLERININ BOS OLUP OLMADIGINI TUTUYOR

        //Boardun constructorinda initialize edilece

        double [][]XboardMatrix = new double[5][11];
        double [][]YboardMatrix = new double[5][11];

        int [][] isFull = game.levelOne.getLevelMatrix();


        for(int i = 0; i < 5; i++) {
            for(int j =0; j < 11; j++) {
                XboardMatrix[i][j] = ((sceneWidth-board.getBoardWidth()) / 2)  + (70 * j);
                YboardMatrix[i][j] = 70 * i;
            }
        }

//--------------------------------------------------------------------------------------------------

        //MOUSE RELEASED EVENT HANDLER
        //This code calculates the position of piece
        EventHandler handler = new EventHandler() {
            @Override
            public void handle(Event event){

                if(event.getSource() == game.pieceOne.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceOne.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceOne.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceView, 40, 440)) {
                        board.putPiece(game.pieceOne, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }

                if(event.getSource() == game.pieceTwo.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceTwo.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceTwo.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceTwoView, 40, 440)) {
                        board.putPiece(game.pieceTwo, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }

                if(event.getSource() == game.pieceFive.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceFive.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceFive.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceFiveView, 280, 440)) {
                        board.putPiece(game.pieceFive, XboardMatrix, YboardMatrix, 280, 440);
                    }
                }

                if(event.getSource() == game.pieceSix.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceSix.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceSix.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceSixView, 570, 440)) {
                        board.putPiece(game.pieceSix, XboardMatrix, YboardMatrix, 570, 440);
                    }
                }

                if(event.getSource() == game.pieceTen.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceTen.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceTen.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceView, 40, 440)) {
                        board.putPiece(game.pieceTen, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }

                else if(event.getSource() == game.pieceEleven.getCurrentImage()) {
                    System.out.println("Layout X11: " +game.pieceEleven.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y11: " +game.pieceEleven.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(piece2View, 280, 440)) {
                        board.putPiece(game.pieceEleven, XboardMatrix, YboardMatrix, 280, 440);
                    }
                }

                else if(event.getSource() == game.pieceTwelve.getCurrentImage()) {
                    System.out.println("Layout X12: " +game.pieceTwelve.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y12: " +game.pieceTwelve.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(piece3View, 570, 440)) {
                        board.putPiece(game.pieceTwelve, XboardMatrix, YboardMatrix, 570, 440);
                    }
                }

            }
        };
//--------------------------------------------------------------------------------------------------


        //MOUSE Pressed EVENT HANDLER
        //This code calculates the position of piece
        EventHandler pressedHandler = new EventHandler() {
            @Override
            public void handle(Event event) {
                if (event.getSource() == game.pieceTen.getCurrentImage()) {
                    selectedPiece = game.pieceTen;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceTen.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                } else if (event.getSource() == game.pieceTwo.getCurrentImage()) {
                    selectedPiece = game.pieceTwo;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceTwo.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == game.pieceFive.getCurrentImage()) {
                    selectedPiece = game.pieceFive;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceFive.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == game.pieceSix.getCurrentImage()) {
                    selectedPiece = game.pieceSix;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceSix.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == game.pieceEleven.getCurrentImage()) {
                    selectedPiece = game.pieceEleven;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceEleven.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                } else if (event.getSource() == game.pieceTwelve.getCurrentImage()) {
                    selectedPiece = game.pieceTwelve;
                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (board.boardMatrix[i][j] == game.pieceTwelve.getPieceId()) {
                                board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }
            }
        };

//--------------------------------------------------------------------------------------------------


        //MOUSE Pressed EVENT HANDLER
        //This code calculates the position of piece
//        EventHandler rightPressedHandler = new EventHandler() {
//            @Override
//            public void handle(Event event) {
//
//
//                if (event.getSource() == game.pieceTen.getCurrentImage()) {
//                    game.pieceTen.getCurrentImage().setRotate(game.pieceTen.getCurrentImage().getRotate() + 90);
//                    Bloom bloom = new Bloom();
//                    game.pieceTen.getCurrentImage().setCache(true);
//                    bloom.setThreshold(1.0);
//                    game.pieceTen.getCurrentImage().setSmooth(true);
//
//                } else if (event.getSource() == game.pieceTwo.getCurrentImage()) {
//                        game.pieceEleven.getCurrentImage().setRotate(game.pieceTwo.getCurrentImage().getRotate() + 90);
//
//                } else if (event.getSource() == game.pieceFive.getCurrentImage()) {
//                    game.pieceFive.getCurrentImage().setRotate(game.pieceFive.getCurrentImage().getRotate() + 90);
//
//                } else if (event.getSource() == game.pieceSix.getCurrentImage()) {
//                    game.pieceSix.getCurrentImage().setRotate(game.pieceSix.getCurrentImage().getRotate() + 90);
//
//                } else if (event.getSource() == game.pieceEleven.getCurrentImage()) {
//                    game.pieceEleven.getCurrentImage().setRotate(game.pieceEleven.getCurrentImage().getRotate() + 90);
//
//                } else if (event.getSource() == game.pieceTwelve.getCurrentImage()) {
//                    game.pieceTwelve.getCurrentImage().setRotate(game.pieceTwelve.getCurrentImage().getRotate() + 90);
//
//                }
//            }
//        };


        backgroundPane.addEventFilter(KeyEvent.KEY_PRESSED, event->{
            if (event.getCode() == KeyCode.SPACE) {
                selectedPiece.getCurrentImage().setRotate(selectedPiece.getCurrentImage().getRotate()+90);
                //System.out.println("")
            }
        });


//--------------------------------------------------------------------------------------------------

        //ADDING EVENTHANDLER TO PIECES
        game.pieceTwo.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceTwo.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        game.pieceFive.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceFive.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        game.pieceSix.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceSix.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        //game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_CLICKED, handler);

        game.pieceEleven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceEleven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED,  pressedHandler);

        game.pieceTwelve.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceTwelve.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED,  pressedHandler);


//        if(board.isFull()) {
//            //Board board = new Board(game.levelOne.getLevelMatrix(), sceneWidth, sceneHeight);
//            GamePlayController secondLevel = new GamePlayController();
//            secondLevel.currentLevel = 1;
//            secondLevel.board = new Board(game.levels[currentLevel].getLevelMatrix(), sceneWidth, sceneHeight);
//            //secondLevel.initialize("/Users/egeakin/IdeaProjects/Version2IQNude/src/sample/GamePlayController.java", );
//            secondLevel.initialize(location, resources);
//        }


//--------------------------------------------------------------------------------------------------

        String style = "-fx-background-color: rgba(241, 235, 174, 0.8);";
        backgroundPane.setStyle(style);

        backgroundPane.setBottom(pieceBox);
        backgroundPane.setTop(menuPane);

//--------------------------------------------------------------------------------------------------

        // add the scalable pane to the scene
        Scene scene = new Scene(backgroundPane, sceneWidth, sceneHeight);

        // setup the stageprimaryStage.setTitle("IQ PUZZLER PRO");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setResizable(false);

    }

}
