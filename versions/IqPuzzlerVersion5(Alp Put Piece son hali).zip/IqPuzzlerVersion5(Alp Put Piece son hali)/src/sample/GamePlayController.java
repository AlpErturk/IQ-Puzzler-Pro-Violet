package sample;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import jfxtras.labs.util.event.MouseControlUtil;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;

public class GamePlayController implements Initializable {

    final int xTopLeft = 0;
    final int yTopLeft = -560;
    final int sceneWidth = 1500;
    final int sceneHeight = 1000;
    public static int timerPosition = 0;


    @Override
    public void initialize(URL location, ResourceBundle resources){




        Game game = Game.getInstance();
        Board board = new Board(game.levelOne.getLevelMatrix(), sceneWidth, sceneHeight);

        Stage primaryStage = new Stage();
        //Pane panel = new Pane();
        //Button button = new Button("tria");

        //panel.getChildren().addAll(button);

        //Scene scenel = new Scene(panel);
        //primaryStage.setScene(scenel);
        //primaryStage.show(); //BUNU COMMENTLEDIM BI HATA COZULDU HABERINIZ OLSUN

        BorderPane backgroundPane = new BorderPane();
        HBox menuPane = new HBox();
        menuPane.setMinSize(150,150);
        menuPane.setMaxSize(150, 150);
        Button pauseButton = new Button("Pause");
        Button ege = new Button("Ege");
        Label menuLabel = new Label("MENU");

        pauseButton.setAlignment(Pos.BOTTOM_CENTER);

        menuPane.getChildren().addAll(menuLabel);
        menuPane.getChildren().addAll(ege);
        menuPane.getChildren().addAll(pauseButton);

        String styleMenu = "-fx-background-color: rgba(80,58,37,0);";
        menuPane.setStyle(styleMenu);

        // use it's predefined content pane as pieceBox pane
        Pane pieceBox = new Pane();
        pieceBox.setMinHeight(sceneHeight - menuPane.getHeight());
        pieceBox.setMinWidth(sceneWidth);

        ImageView boardView = board.getBoardView();
        ImageView pieceView = game.pieceTen.getCurrentImage();
        ImageView piece2View = game.pieceEleven.getCurrentImage();
        ImageView piece3View = game.pieceTwelve.getCurrentImage();
        Image timerImage = new Image("file:/Users/egeakin/IdeaProjects/Version2IQ/images/bounce.png");



        ImageView timerView = new ImageView(timerImage);
        pieceBox.getChildren().addAll(timerView);
        timerView.setLayoutY(40);
        timerView.setLayoutX(timerPosition);
        Timer timer = new Timer();

        TimerTask task = new TimerTask()
        {
            public void run()
            {
                timerView.setLayoutX(timerPosition+=10);
                if(timerPosition > sceneWidth)
                    timerPosition  = 0;
            }

        };

        timer.scheduleAtFixedRate(task,100,100);


        MouseControlUtil.makeDraggable(pieceView);
        pieceBox.getChildren().add(pieceView);
        pieceView.setLayoutX(40);
        pieceView.setLayoutY(440);


        MouseControlUtil.makeDraggable(piece2View);
        pieceBox.getChildren().add(piece2View);
        piece2View.setLayoutX(280);
        piece2View.setLayoutY(440);


        MouseControlUtil.makeDraggable(piece3View);
        pieceBox.getChildren().add(piece3View);
        piece3View.setLayoutX(570);
        piece3View.setLayoutY(440);

        pieceBox.getChildren().add(boardView);
        boardView.setLayoutX((sceneWidth-board.getBoardWidth()) / 2 );
        boardView.setLayoutY(0);

//----------------------------------------------------------------------------------------------------------------------

        //BOARD MATRIXI INITIALIZE EDILIYOR VE BIR MATRIX XPOSITIONLARI TUTUYOR BIR MATRIX YPOSITIONLARI TUTUYOR
        //BIR MATRIX TUM BOARD ENTRYLERININ BOS OLUP OLMADIGINI TUTUYOR

        //Boardun constructorinda initialize edilece

        double [][]XboardMatrix = new double[5][11];
        double [][]YboardMatrix = new double[5][11];

        int [][] isFull = game.levelOne.getLevelMatrix();


        for(int i = 0; i < 5; i++) {
            for(int j =0; j < 11; j++) {
                XboardMatrix[i][j] = ((sceneWidth-board.getBoardWidth()) / 2)  + (70 * j);
                YboardMatrix[i][j] = 70 * i;
            }
        }

//--------------------------------------------------------------------------------------------------

        //MOUSE RELEASED EVENT HANDLER
        //This code calculates the position of piece
        EventHandler handler = new EventHandler() {
            @Override
            public void handle(Event event){
                if(event.getSource() == game.pieceTen.getCurrentImage()) {
                    System.out.println("Layout X10: " +game.pieceTen.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +game.pieceTen.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(pieceView, 40, 440)) {
                        board.putPiece(game.pieceTen, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }

                else if(event.getSource() == game.pieceEleven.getCurrentImage()) {
                    System.out.println("Layout X11: " +game.pieceEleven.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y11: " +game.pieceEleven.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(piece2View, 280, 440)) {
                        board.putPiece(game.pieceEleven, XboardMatrix, YboardMatrix, 280, 440);
                    }
                }

                else if(event.getSource() == game.pieceTwelve.getCurrentImage()) {
                    System.out.println("Layout X12: " +game.pieceTwelve.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y12: " +game.pieceTwelve.getCurrentImage().getLayoutY());
                    if (board.checkPieceBoundary(piece3View, 570, 440)) {
                        board.putPiece(game.pieceTwelve, XboardMatrix, YboardMatrix, 570, 440);
                    }
                }

            }
        };
//--------------------------------------------------------------------------------------------------

        //ADDING EVENTHANDLER TO PIECES
        game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceEleven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        game.pieceTwelve.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);

//--------------------------------------------------------------------------------------------------

        String style = "-fx-background-color: rgba(241, 235, 174, 0.8);";
        backgroundPane.setStyle(style);


        backgroundPane.setBottom(pieceBox);
        backgroundPane.setTop(menuPane);

//--------------------------------------------------------------------------------------------------

        // add the scalable pane to the scene
        Scene scene = new Scene(backgroundPane, sceneWidth, sceneHeight);

        // setup the stageprimaryStage.setTitle("IQ PUZZLER PRO");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setResizable(false);

    }

}
