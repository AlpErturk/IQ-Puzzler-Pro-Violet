package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.Button;


import java.io.IOException;
import java.sql.*;

public class signUpController {

    public Button backButton;
    public Button signUpButton;
    public TextField usernameField;
    public TextField passwordField;


    ConnectionManager connectionManager = new ConnectionManager();
    Connection connection = null;

    public void signUpButtonHandle(ActionEvent event) throws IOException{
        //if the sign up button is pressed
        String username = usernameField.getText();
        String password = passwordField.getText();

        if(username != "" && password != ""){
            //check if user present in database
            if(registerUser(username, password)){
                //register user is successful
                System.out.println("User sign up is successful");

                //identify user !!

                Parent root = FXMLLoader.load(getClass().getResource("mainMenu.fxml"));
                Stage m = Main.getMainStage();
                Scene t = new Scene(root);
                t.setRoot(root);
                m.setScene(t);
                Main.setMainStage(m);

            }
            else{
                System.out.println("Unsuccessful sign up");
            }

        }

    }

    public boolean registerUser(String username, String password){
        //add new user to database if username is not taken

        //first open database connection
        openDatabaseConnection();

        if(!userExists(username)){
            System.out.println("User does not exists");
            //user is not in database
            int levelNo = 0; //initial level is 0

            String sql = "INSERT INTO login_table(username,password,level) VALUES(?,?,?)";
            try {
                PreparedStatement pstmt = connection.prepareStatement(sql);
                pstmt.setString(1,username);
                pstmt.setString(2,password);
                pstmt.setInt(3,levelNo);
                pstmt.executeUpdate();

                return true;

            } catch(SQLException e){
                System.out.println("Error in Database insertion");
                return false;
            }
        }
        else{
            System.out.println("User exists!");
        }
        return false;
    }

    public boolean userExists(String user){
        //check database
        //return true if user is in database
        boolean result = false;
        ResultSet rs = null;
        Statement st = null;
        try{
            st = connection.createStatement();
            rs = st.executeQuery("SELECT * FROM login_table WHERE username IN (user)");

            if(rs == null){
                //user does not exist
                result = false; //not necessary
            }
            else{
                //user exists
                result = true;
            }
        } catch(SQLException e){
            System.out.println("Exception in userExists method");
        }


        return result;
    }



    public void openDatabaseConnection(){
        connection = connectionManager.getConnection(); // we will use this connection to change database
    }

    public void closeDatabaseConnection(){
        try{
            connection.close();

        } catch(SQLException e){
            System.out.println("Cannot close Database");
        }

    }

    public void backButtonHandle() throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("logInScreen.fxml"));
        Stage m = Main.getMainStage();
        Scene t = Main.getMainStage().getScene();
        t.setRoot(root);
        m.setScene(t);
        Main.setMainStage(m);
    }
}
