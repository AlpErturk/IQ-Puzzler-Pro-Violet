package sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


//DATABASE CONNECTION MANAGER
public class ConnectionManager {
    private static String url = "jdbc:sqlite:C:/Users/gulsa/Desktop/SQLite/loginDB.db";
    private static Connection connection = null;

    public static Connection getConnection(){
        try{
            System.out.println("in try block");
            try {
                Class.forName("org.sqlite.JDBC");
                connection = DriverManager.getConnection(url);
            }catch(ClassNotFoundException e){
                System.out.println("Driver not found!");
            }
        } catch(SQLException e){

        }
        return connection;
    }
}
