
/*package sample;

import java.sql.*;

public class DatabaseManager {
    // all operations related to database will be done in this class

    ConnectionManager connectionManager = new ConnectionManager();
    Connection connection = null; //database connection

    public boolean registerUser(String username, String password){
        //add new user to database if username is not taken

        //first open database connection
        openDatabaseConnection();

        if(!userExists(username)){
            System.out.println("User does not exists");
            //user is not in database
            int levelNo = 0; //initial level is 0

            String sql = "INSERT INTO login_table(username,password,level) VALUES(?,?,?)";
            try {
                PreparedStatement pstmt = connection.prepareStatement(sql);
                pstmt.setString(1,username);
                pstmt.setString(2,password);
                pstmt.setInt(3,levelNo);
                pstmt.executeUpdate();

                return true;

            } catch(SQLException e){
                System.out.println("Error in Database insertion");
                return false;
            }
        }
        else{
            System.out.println("User exists!");
        }
        return false;
    }

    public boolean userExists(String user){
        //check database
        //return true if user is in database
        boolean result = false;
        ResultSet rs = null;
        Statement st = null;
        try{
            st = connection.createStatement();
            rs = st.executeQuery("SELECT * FROM login_table WHERE username IN (user)");

            if(rs == null){
                //user does not exist
                result = false; //not necessary
            }
            else{
                //user exists
                result = true;
            }
        } catch(SQLException e){
            System.out.println("Exception in userExists method");
        }


        return result;
    }



    public void openDatabaseConnection(){
        connection = connectionManager.getConnection(); // we will use this connection to change database
    }

    public void closeDatabaseConnection(){
        try{
            connection.close();

        } catch(SQLException e){
            System.out.println("Cannot close Database");
        }

    }

}

*/
