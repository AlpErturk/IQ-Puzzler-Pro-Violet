package sample;

import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.EventHandler;
import java.io.IOException;

public class AdditionController {

    private final AdditionModel model ;

    public AdditionController(AdditionModel model) {
        this.model = model ;
    }


    /*
    public void updateX(String x) {
        model.setX(convertStringToInt(x));
    }

    public void updateY(String y) {
        model.setY(convertStringToInt(y));
    }


    private int convertStringToInt(String s) {
        if (s == null || s.isEmpty()) {
            return 0 ;
        }
        if ("-".equals(s)) {
            return 0 ;
        }
        return Integer.parseInt(s);
    }
    */


    javafx.event.EventHandler handler = new javafx.event.EventHandler() {
        @Override
        public void handle(Event event) {
            Parent root = null;
            try {

                root = FXMLLoader.load(getClass().getResource("mainMenu.fxml"));
                Stage m = Main.getMainStage();
                Scene t = new Scene(root, 600,400);
                t.setRoot(root);
                m.setScene(t);
                Main.setMainStage(m);

            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }};







}