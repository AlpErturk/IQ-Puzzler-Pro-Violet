package sample;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javafx.scene.canvas.GraphicsContext;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.TextFormatter.Change;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import jfxtras.labs.util.event.MouseControlUtil;
import java.awt.image.BufferedImage;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class AdditionView {

    private BorderPane backgroundPane;
    private GridPane view ;
    private TextField xField;
    private TextField yField;
    private Label sumLabel;
    public static int timerPosition = 0;

    private AdditionController controller ;
    private AdditionModel model ;
    Piece selectedPiece;

    ImageView boardView;


    //Initialization of All Pieces in View

    //Level 2 Pieces
    ImageView pieceTwoView;
    ImageView pieceFiveView;
    ImageView pieceSixView;

    //Level 1 Pieces
    ImageView pieceTenView;
    ImageView pieceElevenView;
    ImageView pieceTwelveView;

    //Other Pieces
    ImageView pieceOneView;
    ImageView pieceThreeView;
    ImageView pieceFourView;
    ImageView pieceSevenView;
    ImageView pieceEightView;
    ImageView pieceNineView;


    public AdditionView(AdditionController controller, AdditionModel model) {

        this.controller = controller ;
        this.model = model ;

        createAndConfigurePane();

        createAndLayoutControls();

    }

    public Parent asParent() {
        return backgroundPane ;
    }


    private void updateIfNeeded(Number value, TextField field) {
        String s = value.toString() ;
        if (! field.getText().equals(s)) {
            field.setText(s);
        }
    }


    private void createAndLayoutControls() {
    }



    public void creatAndConfigurePieces(){

    }


    private void createAndConfigurePane() {

        backgroundPane = new BorderPane();
        HBox menuPane = new HBox();
        menuPane.setMinSize(150,150);
        menuPane.setMaxSize(150, 150);
        Button pauseButton = new Button("Pause");

        pauseButton.setOnAction(controller.handler);

        Button ege = new Button("Ege");
        Label menuLabel = new Label("MENU");
        String styleMenu = "-fx-background-color: rgba(80,58,37,0);";
        menuPane.setStyle(styleMenu);

        pauseButton.setAlignment(Pos.BOTTOM_CENTER);

        menuPane.getChildren().addAll(menuLabel);
        menuPane.getChildren().addAll(ege);
        menuPane.getChildren().addAll(pauseButton);

        Pane pieceBox = new Pane();
        pieceBox.setMinHeight(model.sceneHeight - menuPane.getHeight());
        pieceBox.setMinWidth(model.sceneWidth);

        Image timerImage = new Image("file:/Users/egeakin/IdeaProjects/Version2IQNude 2/images/bounce.png");
        ImageView timerView = new ImageView(timerImage);
        pieceBox.getChildren().addAll(timerView);
        timerView.setLayoutY(40);
        timerView.setLayoutX(timerPosition);
        Timer timer = new Timer();

        TimerTask task = new TimerTask()
        {
            public void run()
            {
                timerView.setLayoutX(timerPosition+=10);
                if(timerPosition > model.getSceneWidth())
                    timerPosition  = 0;
            }
        };

        timer.scheduleAtFixedRate(task,100,100);

        model.getBoard().printBoardMatrix();
        model.getBoard().updateBoard();
        ImageView boardView = model.getBoard().getBoardView();

        //Level 2 Pieces
        pieceTwoView = model.getGame().pieceTwo.getCurrentImage();
        pieceFiveView = model.getGame().pieceFive.getCurrentImage();
        pieceSixView = model.getGame().pieceSix.getCurrentImage();

        //Level 1 Pieces
        pieceTenView = model.getGame().pieceTen.getCurrentImage();
        pieceElevenView = model.getGame().pieceEleven.getCurrentImage();
        pieceTwelveView = model.getGame().pieceTwelve.getCurrentImage();

        //Other Level Pieces
        pieceOneView = model.getGame().pieceOne.getCurrentImage();
        pieceThreeView = model.getGame().pieceThree.getCurrentImage();
        pieceFourView = model.getGame().pieceFour.getCurrentImage();
        pieceSevenView = model.getGame().pieceSeven.getCurrentImage();
        pieceEightView = model.getGame().pieceEight.getCurrentImage();
        pieceNineView = model.getGame().pieceNine.getCurrentImage();


        // PRINTING AND CONFIGURING THE LOCATIONS OF PIECES LOGIC

        double []xPositions = new double[9];
        double []yPositions = new double[9];
        //init x positions
        xPositions[0] = 5;
        xPositions[1] = 290;
        xPositions[2] = 575;
        xPositions[3] = 860;
        xPositions[4] = 1145;
        xPositions[5] = 5;
        xPositions[6] = 5;
        xPositions[7] = 775;
        xPositions[8] = 775;

        yPositions[0] = 450;
        yPositions[1] = 450;
        yPositions[2] = 450;
        yPositions[3] = 450;
        yPositions[4] = 450;
        yPositions[5] = 0;
        yPositions[6] = 285;
        yPositions[7] = 0;
        yPositions[8] = 285;

        ArrayList<Piece> unUsuedPieces = model.game.twoDLevels[model.game.getCurrent2DLevel()].getUnusedPieces();
        //System.out.println( model.game.twoDLevels[model.game.getCurrent2DLevel()].getUnusedPieces().get(0).getPieceId());
        ArrayList<ImageView> unUsedPiecesView = new ArrayList<ImageView>();
        model.board.updateBoard();
        System.out.print("buraya girdi");

        //assign imageviews of pieces
        for(int i = 0; i < unUsuedPieces.size(); i++){
            unUsedPiecesView.add(i, unUsuedPieces.get(i).getCurrentImage());
            unUsedPiecesView.get(i).relocate(xPositions[i], yPositions[i]);
            pieceBox.getChildren().add(unUsedPiecesView.get(i));
            MouseControlUtil.makeDraggable(unUsuedPieces.get(i).getCurrentImage());
        }


        /*
        MouseControlUtil.makeDraggable(pieceView);
        pieceBox.getChildren().add(pieceView);
        pieceView.setLayoutX(40);
        pieceView.setLayoutY(440);


        MouseControlUtil.makeDraggable(piece2View);
        pieceBox.getChildren().add(piece2View);
        piece2View.setLayoutX(280);
        piece2View.setLayoutY(440);


        MouseControlUtil.makeDraggable(piece3View);
        pieceBox.getChildren().add(piece3View);
        piece3View.setLayoutX(570);
        piece3View.setLayoutY(440);

        */

        pieceBox.getChildren().add(boardView);
        boardView.setLayoutX((model.sceneWidth- model.board.getBoardWidth()) / 2 );
        boardView.setLayoutY(0);

        /*
        MouseControlUtil.makeDraggable(pieceTwoView);
        pieceBox.getChildren().add(pieceTwoView);
        pieceTwoView.setLayoutX(40);
        pieceTwoView.setLayoutY(440);


        MouseControlUtil.makeDraggable(pieceFiveView);
        pieceBox.getChildren().add(pieceFiveView);
        pieceFiveView.setLayoutX(280);
        pieceFiveView.setLayoutY(440);


        MouseControlUtil.makeDraggable(pieceSixView);
        pieceBox.getChildren().add(pieceSixView);
        pieceSixView.setLayoutX(570);
        pieceSixView.setLayoutY(440);

        pieceBox.getChildren().add(boardView);
        boardView.setLayoutX((sceneWidth-model.board.getBoardWidth()) / 2 );
        boardView.setLayoutY(0);
        */


//----------------------------------------------------------------------------------------------------------------------

        //BOARD MATRIXI INITIALIZE EDILIYOR VE BIR MATRIX XPOSITIONLARI TUTUYOR BIR MATRIX YPOSITIONLARI TUTUYOR
        //BIR MATRIX TUM BOARD ENTRYLERININ BOS OLUP OLMADIGINI TUTUYOR

        //Boardun constructorinda initialize edilece

        double [][]XboardMatrix = new double[5][11];
        double [][]YboardMatrix = new double[5][11];

        for(int i = 0; i < 5; i++) {
            for(int j =0; j < 11; j++) {
                XboardMatrix[i][j] = ((model.sceneWidth-model.board.getBoardWidth()) / 2)  + (70 * j);
                YboardMatrix[i][j] = 70 * i;
            }
        }

//--------------------------------------------------------------------------------------------------

        //MOUSE RELEASED EVENT HANDLER
        //This code calculates the position of piece
        EventHandler handler = new EventHandler() {
            @Override
            public void handle(Event event){

                if(event.getSource() == model.game.pieceOne.getCurrentImage()) {
                    System.out.println("Layout X10: " +model.game.pieceOne.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +model.game.pieceOne.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceOneView, 40, 440)) {
                        model.board.putPiece(model.game.pieceOne, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }

                if(event.getSource() == model.game.pieceTwo.getCurrentImage()) {
                    System.out.println("Layout X10: " +model.game.pieceTwo.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +model.game.pieceTwo.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceTwoView, 40, 440)) {
                        model.board.putPiece(model.game.pieceTwo, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }

                if(event.getSource() == model.game.pieceThree.getCurrentImage()) {
                    System.out.println("Layout X10: " +model.game.pieceThree.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +model.game.pieceThree.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceThreeView, 40, 440)) {
                        model.board.putPiece(model.game.pieceThree, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }


                if(event.getSource() == model.game.pieceFive.getCurrentImage()) {
                    System.out.println("Layout X10: " +model.game.pieceFive.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +model.game.pieceFive.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceFiveView, 280, 440)) {
                        model.board.putPiece(model.game.pieceFive, XboardMatrix, YboardMatrix, 280, 440);
                    }
                }

                if(event.getSource() == model.game.pieceSix.getCurrentImage()) {
                    System.out.println("Layout X10: " +model.game.pieceSix.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +model.game.pieceSix.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceSixView, 570, 440)) {
                        model.board.putPiece(model.game.pieceSix, XboardMatrix, YboardMatrix, 570, 440);
                    }
                }

                if(event.getSource() == model.game.pieceSeven.getCurrentImage()) {
                    System.out.println("Layout X10: " +model.game.pieceSeven.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +model.game.pieceSeven.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceSevenView, 570, 440)) {
                        model.board.putPiece(model.game.pieceSeven, XboardMatrix, YboardMatrix, 570, 440);
                    }
                }

                if(event.getSource() == model.game.pieceEight.getCurrentImage()) {
                    System.out.println("Layout X10: " +model.game.pieceEight.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +model.game.pieceEight.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceEightView, 570, 440)) {
                        model.board.putPiece(model.game.pieceEight, XboardMatrix, YboardMatrix, 570, 440);
                    }
                }

                if(event.getSource() == model.game.pieceNine.getCurrentImage()) {
                    System.out.println("Layout X10: " +model.game.pieceNine.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +model.game.pieceNine.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceNineView, 570, 440)) {
                        model.board.putPiece(model.game.pieceNine, XboardMatrix, YboardMatrix, 570, 440);
                    }
                }

                if(event.getSource() == model.game.pieceTen.getCurrentImage()) {
                    System.out.println("Layout X10: " +model.game.pieceTen.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y10: " +model.game.pieceTen.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceTenView, 40, 440)) {
                        model.board.putPiece(model.game.pieceTen, XboardMatrix, YboardMatrix, 40, 440);
                    }
                }

                else if(event.getSource() == model.game.pieceEleven.getCurrentImage()) {
                    System.out.println("Layout X11: " +model.game.pieceEleven.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y11: " +model.game.pieceEleven.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceElevenView, 280, 440)) {
                        model.board.putPiece(model.game.pieceEleven, XboardMatrix, YboardMatrix, 280, 440);
                    }
                }

                else if(event.getSource() == model.game.pieceTwelve.getCurrentImage()) {
                    System.out.println("Layout X12: " +model.game.pieceTwelve.getCurrentImage().getLayoutX());
                    System.out.println("Layout Y12: " +model.game.pieceTwelve.getCurrentImage().getLayoutY());
                    if (model.board.checkPieceBoundary(pieceTwelveView, 570, 440)) {
                        model.board.putPiece(model.game.pieceTwelve, XboardMatrix, YboardMatrix, 570, 440);
                    }
                }

            }
        };

//--------------------------------------------------------------------------------------------------


        //MOUSE Pressed EVENT HANDLER
        //This code calculates the position of piece
        EventHandler pressedHandler = new EventHandler() {
            @Override
            public void handle(Event event) {

                if (event.getSource() == model.game.pieceOne.getCurrentImage()) {
                    selectedPiece = model.game.pieceOne;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] == model.game.pieceOne.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == model.game.pieceTwo.getCurrentImage()) {
                    selectedPiece = model.game.pieceTwo;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] == model.game.pieceTwo.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == model.game.pieceThree.getCurrentImage()) {
                    selectedPiece = model.game.pieceThree;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] == model.game.pieceThree.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == model.game.pieceFour.getCurrentImage()) {
                    selectedPiece = model.game.pieceFour;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] == model.game.pieceFour.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() ==  model.game.pieceFive.getCurrentImage()) {
                    selectedPiece = model.game.pieceFive;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] ==  model.game.pieceFive.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() ==  model.game.pieceSix.getCurrentImage()) {
                    selectedPiece =  model.game.pieceSix;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] ==  model.game.pieceSix.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == model.game.pieceSeven.getCurrentImage()) {
                    selectedPiece = model.game.pieceSeven;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] == model.game.pieceSeven.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == model.game.pieceEight.getCurrentImage()) {
                    selectedPiece = model.game.pieceEight;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] == model.game.pieceEight.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == model.game.pieceNine.getCurrentImage()) {
                    selectedPiece = model.game.pieceNine;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] == model.game.pieceNine.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() == model.game.pieceTen.getCurrentImage()) {
                    selectedPiece = model.game.pieceTen;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] == model.game.pieceTen.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() ==  model.game.pieceEleven.getCurrentImage()) {
                    selectedPiece =  model.game.pieceEleven;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] ==  model.game.pieceEleven.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                } else if (event.getSource() ==  model.game.pieceTwelve.getCurrentImage()) {
                    selectedPiece =  model.game.pieceTwelve;
                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] ==  model.game.pieceTwelve.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }
            }
        };

        //This code is for rotating the pressed piece
        backgroundPane.addEventFilter(KeyEvent.KEY_PRESSED, event->{
            if (event.getCode() == KeyCode.SPACE) {
                selectedPiece.getCurrentImage().setRotate(selectedPiece.getCurrentImage().getRotate()+90);
                //System.out.println("")
            }
        });


        backgroundPane.addEventFilter(KeyEvent.KEY_PRESSED, event-> {
                    if (event.getCode() == KeyCode.V && selectedPiece.getCurrentImage().getScaleX() == 1) {
                        //selectedPiece.getCurrentImage().setRotate(selectedPiece.getCurrentImage().getRotate() + 90);
                        //System.out.println("")
                        selectedPiece.getCurrentImage().setScaleX(-1);
                    }
                    else if (event.getCode() == KeyCode.V && selectedPiece.getCurrentImage().getScaleX() == -1) {
                        selectedPiece.getCurrentImage().setScaleX(1);
                    }
        });

        backgroundPane.addEventFilter(KeyEvent.KEY_PRESSED, event-> {
            if (event.getCode() == KeyCode.H && selectedPiece.getCurrentImage().getScaleY() == 1) {
                //selectedPiece.getCurrentImage().setRotate(selectedPiece.getCurrentImage().getRotate() + 90);
                //System.out.println("")
                selectedPiece.getCurrentImage().setScaleY(-1);
            }
            else if (event.getCode() == KeyCode.H && selectedPiece.getCurrentImage().getScaleY() == -1) {
                selectedPiece.getCurrentImage().setScaleY(1);
            }


        });


        // Get source image dimension
       // int pieceWidth = 280;
       // int pieceHeight = 280;
        //BufferedImage selectedPieceBuffered = selectedPiece.getCurrentImage().getImage();

        // BufferedImage for mirror image
       // BufferedImage mirroredImage = new BufferedImage(pieceWidth, pieceHeight,
        //        BufferedImage.TYPE_INT_ARGB);

        // Create mirror image pixel by pixel
//        for (int y = 0; y < pieceHeight; y++)
//        {
//            for (int lx = 0, rx = pieceWidth - 1; lx < pieceWidth; lx++, rx--)
//            {
//                // lx starts from the left side of the image
//                // rx starts from the right side of the image
//                // lx is used since we are getting pixel from left side
//                // rx is used to set from right side
//                // get source pixel value
//                Color p = selectedPiece.getCurrentImage().getImage().getRGB(lx, y);
//
//                // set mirror image pixel value
//                selectedPiece.getCurrentImage().setRGB(rx, y, p);
//            }
//        }
//






//--------------------------------------------------------------------------------------------------

        //ADDING EVENTHANDLER TO PIECES

        model.game.pieceOne.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceOne.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        model.game.pieceTwo.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceTwo.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        model.game.pieceThree.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceThree.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        model.game.pieceFour.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceFour.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        model.game.pieceFive.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceFive.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        model.game.pieceSix.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceSix.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        model.game.pieceSeven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceSeven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        model.game.pieceEight.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceEight.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        model.game.pieceNine.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceNine.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        model.game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceTen.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, pressedHandler);

        model.game.pieceEleven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceEleven.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED,  pressedHandler);

        model.game.pieceTwelve.getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, handler);
        model.game.pieceTwelve.getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED,  pressedHandler);


        String style = "-fx-background-color: rgba(241, 235, 174, 0.8);";
        backgroundPane.setStyle(style);
        backgroundPane.setBottom(pieceBox);
        backgroundPane.setTop(menuPane);

    }


    private void configTextFieldForInts(TextField field) {
        field.setTextFormatter(new TextFormatter<Integer>((Change c) -> {
            if (c.getControlNewText().matches("-?\\d*")) {
                return c ;
            }
            return null ;
        }));
    }

//    public void draw(GraphicsContext g){
//        //(javafx.scene.image.Image,
//        // sourceX,sourceY, sourceWidth,sourceHeight,
//        //outputX,outputY,outputWidth,outputHeight);
//        g.drawImage(selectedPiece.getCurrentImage().getImage(), 0, 0, 280, 280, 280,0,-280,280);
//    }



}