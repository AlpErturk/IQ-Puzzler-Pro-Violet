package sample;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.TextFormatter.Change;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import jfxtras.labs.util.event.MouseControlUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class AdditionView {

    private BorderPane backgroundPane;
    private BorderPane menuPane;
    private int timerPosition;
    private int levelTime;
    private int time;


    private AdditionController controller;
    private AdditionModel model ;
    private GameField field;

    ImageView boardView;


    public AdditionView(AdditionController controller, AdditionModel model) {


        this.controller = controller ;
        this.model = model ;

        createAndConfigurePane();
        createAndLayoutControls();

        levelTime = model.getLevelTime();
        time = 0;

        field = new GameField(model.game.twoDLevels[model.game.getCurrent2DLevel()]);

    }

    public Parent asParent() {
        return backgroundPane ;
    }


    private void updateIfNeeded(Number value, TextField field) {
        String s = value.toString() ;
        if (! field.getText().equals(s)) {
            field.setText(s);
        }
    }


    private void createAndLayoutControls() {
    }

    private void createAndConfigurePane() {

        backgroundPane = new BorderPane();
        menuPane = new BorderPane();

        menuPane.setMinSize(150,150);
        menuPane.setMaxSize(150, 150);

        Button pauseButton = new Button("Pause");
        pauseButton.setOnAction(controller.handler);
        Button ege = new Button("Ege");

        menuPane.getChildren().addAll(ege);
        menuPane.getChildren().addAll(pauseButton);

        ege.setLayoutX(50);
        ege.setLayoutY(60);
        pauseButton.setLayoutX(50);
        pauseButton.setLayoutY(20);

        Pane pieceBox = new Pane();
        pieceBox.setMinHeight(model.sceneHeight - menuPane.getHeight());
        pieceBox.setMinWidth(model.sceneWidth);


        Image timerImage = new Image("file:/Users/safaaskin/IdeaProjects/Version2IQNude/images/menu/progress.png");
        ImageView timerView = new ImageView(timerImage);
        Image lineImage = new Image("file:/Users/safaaskin/IdeaProjects/Version2IQNude/images/menu/theLine.png");
        ImageView lineView = new ImageView(lineImage);

        menuPane.getChildren().addAll(lineView);
        menuPane.getChildren().addAll(timerView);

        lineView.setLayoutY(60);

        int timerStartingX = (model.getSceneWidth() - 660) / 2;

        lineView.setLayoutX(timerStartingX);
        timerView.setLayoutY(55);
        timerView.setLayoutX(timerStartingX);
        timerPosition = timerStartingX;

        Timer timer = new Timer();

        TimerTask task = new TimerTask()
        {
            public void run()
            {
                time++;
                timerView.setLayoutX(timerPosition += 2);

                if(timerPosition > model.getSceneWidth())
                    timerPosition  = timerStartingX;

                if(time == levelTime){
                    timer.cancel();
                }
            }
        };

        if(time == levelTime){
            try {
                Parent root = FXMLLoader.load(getClass().getResource("PauseAlertBox.fxml"));
                Stage window = new Stage();
                Scene scene = new Scene(root);
                window.setTitle("Pause");
                window.setScene(scene);
                window.centerOnScreen();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        timer.scheduleAtFixedRate(task,1000,100);


        //model.getBoard().printBoardMatrix();
        //model.getBoard().updateBoard();
        ImageView boardView = model.game.twoDLevels[model.game.getCurrent2DLevel()].getBoardView();




        ArrayList<Piece> unUsuedPieces = model.game.twoDLevels[model.game.getCurrent2DLevel()].getUnusedPieces();
        //System.out.println( model.game.twoDLevels[model.game.getCurrent2DLevel()].getUnusedPieces().get(0).getPieceId());
        ArrayList<ImageView> unUsedPiecesView = new ArrayList<ImageView>();
        //model.board.updateBoard();

        //assign imageviews of pieces
        for(int i = 0; i < unUsuedPieces.size(); i++){
            unUsedPiecesView.add(i, unUsuedPieces.get(i).getCurrentImage());
            unUsedPiecesView.get(i).relocate(model.getxPositions()[i], model.getyPositions()[i]);
            pieceBox.getChildren().add(unUsedPiecesView.get(i));
            MouseControlUtil.makeDraggable(unUsuedPieces.get(i).getCurrentImage());
        }


        pieceBox.getChildren().add(boardView);
        boardView.setLayoutX((model.sceneWidth - model.board.getBoardWidth()) / 2 );
        boardView.setLayoutY(0);








//--------------------------------------------------------------------------------------------------

        /*
        //13:12 de bu kodu contollerin içinde taşıdım burda kalmasına gerek yok artık
        //This code calculates the position of piece
        EventHandler pressedHandler = new EventHandler() {
            @Override
            public void handle(Event event) {
                if (event.getSource() == model.game.pieceTen.getCurrentImage()) {
                    selectedPiece = model.game.pieceTen;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] == model.game.pieceTen.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                } else if (event.getSource() == model.game.pieceTwo.getCurrentImage()) {
                    selectedPiece = model.game.pieceTwo;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] == model.game.pieceTwo.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() ==  model.game.pieceFive.getCurrentImage()) {
                    selectedPiece = model.game.pieceFive;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] ==  model.game.pieceFive.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() ==  model.game.pieceSix.getCurrentImage()) {
                    selectedPiece =  model.game.pieceSix;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] ==  model.game.pieceSix.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }

                else if (event.getSource() ==  model.game.pieceEleven.getCurrentImage()) {
                    selectedPiece =  model.game.pieceEleven;

                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] ==  model.game.pieceEleven.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                } else if (event.getSource() ==  model.game.pieceTwelve.getCurrentImage()) {
                    selectedPiece =  model.game.pieceTwelve;
                    for (int i = 0; i < 5; i++) {
                        for (int j = 0; j < 11; j++) {
                            if (model.board.boardMatrix[i][j] ==  model.game.pieceTwelve.getPieceId()) {
                                model.board.boardMatrix[i][j] = 0;
                            }
                        }
                    }
                }
            }
        };
*/



        backgroundPane.addEventFilter(KeyEvent.KEY_PRESSED, event->{
            if (event.getCode() == KeyCode.SPACE) {
                controller.getSelectedPiece().getCurrentImage().setRotate(controller.getSelectedPiece().getCurrentImage().getRotate()+90);
                //System.out.println("")
            }
        });


//--------------------------------------------------------------------------------------------------

        //Adding event handler to unused pieces in specific level
        for(int i = 0; i < model.game.twoDLevels[model.game.getCurrent2DLevel()].getUnusedPieces().size(); i++){
            model.game.twoDLevels[model.game.getCurrent2DLevel()].getUnusedPieces().get(i).getCurrentImage().addEventHandler(MouseEvent.MOUSE_RELEASED, controller.releaseHandler);
            model.game.twoDLevels[model.game.getCurrent2DLevel()].getUnusedPieces().get(i).getCurrentImage().addEventHandler(MouseEvent.MOUSE_PRESSED, controller.pressedHandler);
        }


        Image backgroundImage = new Image("file:/Users/safaaskin/IdeaProjects/Version2IQNude/images/menu/snowySecond.png");

        BackgroundImage myBI= new BackgroundImage(backgroundImage,
                BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);


        backgroundPane.setBottom(pieceBox);
        backgroundPane.setTop(menuPane);
        backgroundPane.setBackground(new Background(myBI));
    }

}