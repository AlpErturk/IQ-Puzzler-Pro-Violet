package sample;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class Board {


    final int boardWidth = 770;
    final int boardHeight = 350;


    private int sceneWidth;
    private int sceneHeight;
    private int leftXCoordinate;
    private int topYCoordinate;
    private int rightXCoordinate;
    private int bottomYCoordinate;
    private int treshold;


    public Board(int[][] matrix,int sceneWidth, int sceneHeight){

        boardImage = new Image("file:/Users/egeakin/IdeaProjects/Version2IQNude/images/level2BoardPic2.png");
        boardView = new ImageView(boardImage);
        //boardView.setFitWidth(boardWidth);
        //boardView.setFitHeight(boardHeight);
        boardMatrix = matrix;
        this.sceneHeight = sceneHeight;
        this.sceneWidth = sceneWidth;

        leftXCoordinate = (this.sceneWidth - boardWidth) / 2 ;
        topYCoordinate = 0;
        rightXCoordinate = leftXCoordinate + boardWidth;
        bottomYCoordinate = boardHeight + topYCoordinate;
        treshold = 10;
    }

    //properties of board
    int[][] boardMatrix;
    Image boardImage;
    ImageView  boardView;


    public ImageView getBoardView(){
        return boardView;
    }

    public int getBoardWidth(){
        return boardWidth;
    }

    // no two piece on each other
    public boolean isAvailable(int rowIndex, int columnIndex, int[][] pieceMatrix){
        for(int m = 0; m <4; m++){
            for (int n = 0; n < 4; n++){
                if(n + columnIndex >= 11){
                    int fazlalikColumn = (n + columnIndex) - 11;
                    if(pieceMatrix[m][n] == 1 && boardMatrix[rowIndex+m][columnIndex+n-fazlalikColumn] != 0) {
                        return false;
                    }
                }
                if(rowIndex + m >= 5){
                    int fazlalikRow = (rowIndex + m) - 5;
                    if(pieceMatrix[m][n] == 1 && boardMatrix[rowIndex+m-fazlalikRow][columnIndex+n] != 0) {
                        return false;
                    }
                }

                if(pieceMatrix[m][n] == 1 && boardMatrix[rowIndex+m][columnIndex+n] != 0) {
                    return false;
                }
            }
        }
        return true;
    }


    //check is board full
    public boolean isFull(){
        for(int i = 0; i < 5; i++){
            for(int j = 0; j < 11; j++){
                if(boardMatrix[i][j] == 0)
                    return false;
            }
        }

        return true;
    }

    //Puzlle piecelerinin dogru yerde oluip olmadigini kontrol eden fonksiyon degilse boardun boundarylerinin disindaysa
    //initial positiona geri donecek
    public boolean checkPieceBoundary(ImageView pieceView, double xPosition, double yPosition){
        double currentX = pieceView.getLayoutX();
        double currentY = pieceView.getLayoutY();

        if((currentX < leftXCoordinate || currentX > rightXCoordinate) || (currentY < topYCoordinate ||currentY > bottomYCoordinate)){
            //set piece to its initial place
            pieceView.relocate(xPosition,yPosition);
            System.out.println(leftXCoordinate);
            System.out.println(topYCoordinate);
            System.out.println(rightXCoordinate);
            System.out.print(bottomYCoordinate);
            return false;
        }

        else{
            return true;
        }
    }

    //PIECEI BIRAZ DISARI KOYDUGUMUZDA PICECEI BOARDA FIX EDEN FONKSIYON
    public void putPiece(Piece piece, double [][]XboardMatrix, double [][]YboardMatrix, double initX, double initY){
        double currentX = piece.getCurrentImage().getLayoutX();
        double currentY = piece.getCurrentImage().getLayoutY();
        boolean placeEmpty = false;

        int indexColumn = ((int)currentX - leftXCoordinate) / 70;
        int indexRow = ((int)currentY - topYCoordinate) / 70;


        System.out.println("index row is : " + indexRow);
        System.out.println("index column is: " + indexColumn);


        if(isAvailable(indexRow, indexColumn, piece.getMatrix())){
            if (((XboardMatrix[indexRow][indexColumn] - treshold < currentX) && (currentX < XboardMatrix[indexRow][indexColumn + 1])) || ((YboardMatrix[indexRow][indexColumn] - treshold < currentY) && (currentY < YboardMatrix[indexRow + 1][indexColumn]))) {
                piece.getCurrentImage().relocate(XboardMatrix[indexRow][indexColumn], YboardMatrix[indexRow][indexColumn]);
            }

            //set empty locations to 1
            for(int i = 0; i < 4; i++) {
                for(int j = 0; j < 4; j++) {

                    if(piece.getMatrix()[i][j] == 1) {
                        boardMatrix[indexRow+i][j+indexColumn] = piece.getPieceId();
                    }
                }
            }
        }
        //if place is occupied return iinitial position do not update board
        else{
            piece.getCurrentImage().relocate(initX,initY);
        }


        //print board matrix----------------------------------------------------------------------------------------------------------------------------------------------------------------
        for(int i = 0; i < 5; i++) {
            for(int j =0; j < 11; j++) {
                System.out.print("(");
                System.out.print(boardMatrix[i][j]);
                System.out.print(")");
            }
            System.out.println();
        }
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


        //----------------------------------------------------------------------------------------------------------------------------------------------------------------
        if(isFull()){
            Stage window = new Stage();
            window.initModality(Modality.APPLICATION_MODAL);
            window.setTitle("Pause");

            try {
                Parent root = FXMLLoader.load(getClass().getResource("PauseAlertBox.fxml"));
                Scene scene = new Scene(root);
                window.setScene(scene);
                window.showAndWait();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    }

    public void printBoardMatrix() {
        for(int i = 0; i < 5; i++) {
            for(int j =0; j < 11; j++) {
                System.out.print("(");
                System.out.print(boardMatrix[i][j]);
                System.out.print(")");
            }
            System.out.println();
        }
    }


        /*System.out.println("put piece girdi");
        //Boardun constructorinda initialize edilecek
//        double [][]XboardMatrix = new double[5][11];
//        double [][]YboardMatrix = new double[5][11];
//
//        int [][] isFull = new int[5][11];
//
//
//        for(int i = 0; i < 5; i++) {
//            for(int j =0; j < 11; j++) {
//                XboardMatrix[i][j] = xTopLeft + (66.36)*j;
//                YboardMatrix[i][j] = yTopLeft + (66.36)*i;
//            }
//        }

        double piecePositionX = piece.getCurrentImage().getLayoutX();
        double piecePositionY = piece.getCurrentImage().getLayoutY();

        int indexX = (int) (piecePositionX / (70));
        int indexY = (int) ((piecePositionY + 495) / (70));

        //check that is there any piece on selected place isAvaiable?


        //if(isAvailable(indexX, indexY, piece.getMatrix())){

            if (((piecePositionX > (XboardMatrix[indexY][indexX] - threshold)) && (piecePositionX < (XboardMatrix[indexY][indexX] + 70)) && (((piecePositionY > (YboardMatrix[indexY][indexX] - threshold)) && (piecePositionY < (YboardMatrix[indexY][indexX] + 70)))))) {
                piece.getCurrentImage().setLayoutX(XboardMatrix[indexY][indexX]);
                piece.getCurrentImage().setLayoutY(YboardMatrix[indexY][indexX]);


                for(int i = 0; i < 4; i++) {
                    for(int j = 0; j < 4; j++) {

                        if(piece.getMatrix()[i][j] == 1) {
                            boardMatrix[indexY+j][i+indexX] = 1;
                        }

                    }
                }

                boardMatrix[indexY][indexX] = 1;

                for(int i = 0; i < 5; i++) {
                    for(int j =0; j < 11; j++) {
                        //System.out.print(boardMatrix[i][j]);
                    }
                    System.out.println();
                }

                if(isFull()){
                    System.out.println("GAME OVER");
                    Stage window = new Stage();
                    window.initModality(Modality.APPLICATION_MODAL);
                    window.setTitle("Pause");

                    try {
                        Parent root = FXMLLoader.load(getClass().getResource("PauseAlertBox.fxml"));
                        Scene scene = new Scene(root);
                        window.setScene(scene);
                        window.showAndWait();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }
            */
    }
